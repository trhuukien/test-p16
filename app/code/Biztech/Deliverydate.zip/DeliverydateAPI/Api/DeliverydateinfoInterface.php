<?php
namespace Biztech\DeliverydateAPI\Api;

interface DeliverydateinfoInterface
{
    /**
     *
     * @return string
     */
    public function getDeliveryDateInfo();
}
