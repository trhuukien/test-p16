<?php

namespace Biztech\Deliverydate\Block\Email;

use Magento\Sales\Block\Items\AbstractItems;

class Info extends AbstractItems
{

}
